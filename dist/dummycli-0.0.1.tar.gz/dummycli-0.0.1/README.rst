# DummyCLI package: a first stab at a pip-installable front-end
